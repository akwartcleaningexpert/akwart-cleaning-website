A-KWART CLEANING EXPERT LTD WEBSITE

Included:
- index.html: responsive one-page business website
- Upload this file to a GitHub repository to publish with GitHub Pages.

IMPORTANT BEFORE GOING LIVE:
1. Check every business detail and service description.
2. The quote form uses the visitor's email app (mailto); it is not a database-backed form.
3. Confirm the exact services, coverage area, credentials and any claims before publishing.
4. Replace stock photos if you have your own job photos and permission to use them.
5. Buy a domain separately; domain availability has not been checked.

Suggested domain to check first: akwartcleaning.co.uk
Alternative: akwartcleaningexpert.co.uk

The site is designed for GitHub Pages and does not require a paid hosting plan.
